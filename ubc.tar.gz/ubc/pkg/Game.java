package pkg;
import java.util.Scanner;
import java.util.Random;
import java.util.ArrayList;
import java.io.*;


public class Game{
	Scanner sc = new Scanner(System.in);
    static int timesPlayed = 0;
    
    String currentWord;
    String shuffled;
    String centerLetter;
    String guess;
    InfoBoard board;
    ArrayList<String> answerList = new <String>ArrayList();
    ArrayList<String> unguessedList;
    
	public Game(String currentWord, String centerLetter){
		timesPlayed++;
		this.currentWord = currentWord;
		shuffled = currentWord;
		this.centerLetter = centerLetter;
		board = new InfoBoard(currentWord);
		loadAnswers();
	}
	
	public void loadAnswers(){
		try{
	    	Scanner scan = new Scanner(new File(currentWord+".txt"));
		    scan.nextLine(); //to skip over the 1st line of rankings
	    	while(scan.hasNextLine()){
        		answerList.add(scan.nextLine());
    		}
		} catch(FileNotFoundException e){
			System.out.println("caught");
		}
		unguessedList = answerList;
	}
	public void play(){

	    while(true){
	    	printHoneycomb(shuffled);
	    	System.out.println("enter a word to play! ('m' to see menu options)");
	    	guess = sc.nextLine();
	    	
	    	switch(guess){
	    		case "m":
	    			menu();
	    			break;
    	    
    			case "f":
    				shuffle();
    				break;
    			case "i":
    				board.checkBoard();
    				break;
    			case "t":
    				tutorial();
    				break;
    				
    			case "r":
    				reveal();
    				return;
    			case "s": 
    	    		System.out.println("moving on to the next game!");
    				return;
    			
    			default:
    				isValidWord();
    				break;
    	    }
	    
	       
	    }
	}
	public void menu(){
		System.out.println("these commands are useable at any time: ");
    	System.out.println("--- 's' to skip this game");
    	System.out.println("--- 'i' to see info board");
    	System.out.println("--- 'r' to reveal all answers and move on to the next game");
    	System.out.println("--- 't' to learn how to play");
    	System.out.println("--- 'f' to shuffle honeycomb");
	}
	public void shuffle(){
		ArrayList<String> nons = new ArrayList<String>();
		
		for(int i = 0; i < currentWord.length()-1; i++){
			nons.add(currentWord.substring(i+1, i+2));
		}
		
		shuffled = centerLetter;
		int i = nons.size();
		while(i > 0){
			int ran = (int)(Math.random()*i);
			shuffled += nons.get(ran);
			nons.remove(ran);
			i--;
		}

	}
	public void tutorial(){
		System.out.println("Hi! Here's how to play Imitation Spelling Bee: ");
		System.out.println("The objective of the game is to rack up as many points as possible - achieved through finding valid words.");
		System.out.println("These 'valid words' are defined as real words made from any combination of the letters in the honeycomb.");
		System.out.println("You can use a certain letter as many times as you want, or not at all.");
		System.out.println("However, valid words are at least 4 letters long, include the center letter at least once, and naturally must be real words.");
		System.out.println("That's all! Please have fun :)");
	}
	public void reveal(){
		System.out.println("all answers:");
		System.out.println("--- unguessed: ");
		for(String ans : unguessedList){
			System.out.print(ans + " ");
		}
		System.out.println("\n --- guessed: ");
		board.printWordsFound();
		System.out.println("\n moving on to the next game!");
	}
	
	public void printHoneycomb(String word){
		//     b
		// d       f
		//     a
		// c       g 
		//     n
		System.out.println("    "+word.substring(1,2));
		System.out.println(word.substring(2,3)+"       "+word.substring(3,4));
		System.out.println("    "+word.substring(0,1));
		System.out.println(word.substring(4,5)+"       "+word.substring(5,6));
		System.out.println("    "+word.substring(6,7));
		
	}
	
	//also updates infoboard for me
	public boolean isValidWord(){
	    if(!(guess.length() >= 4)){
	        System.out.println("too short");
	        return false;
	    }
	    if(guess.indexOf(centerLetter) == -1){
	        System.out.println("missing center letter");
	        return false;
	    }
	    for(int i = 0; i < answerList.size(); i++){
	    	if(guess.equals(answerList.get(i))){
	    		points();
	    		board.updateWordsFound(guess);
	    		unguessedList.remove(guess);
	    		return true;
	    	}
	    }
	    System.out.println("not a valid word"); 
	    return false;
	}
	public void points(){
	    int p = 0;
	    if(guess.length() == 4){
	        p = 1;
	    }else{
	        p = guess.length();
	        if(isPangram()){
	            p += 5;
	        }
	    }
	    System.out.println("+"+p+" points!");
	    board.updateTotalPoints(p);
	    //return p;
	}
	//only checks if it uses all the letters, not if it's a valid word
	public boolean isPangram(){
	    for(int i = 0; i < currentWord.length(); i++){
	        if(guess.indexOf(currentWord.substring(i, i+1)) == -1){
	            return false;
	        }   
	    }
	    System.out.println("Pangram!");
	    return true;
	}

}